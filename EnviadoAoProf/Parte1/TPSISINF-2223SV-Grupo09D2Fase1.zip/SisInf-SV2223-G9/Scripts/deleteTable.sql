delete from AMIGO;

delete from TEM;

delete from CRACHAS;

delete from MENSAGENS;

delete from PARTICIPAR;

delete from ESTATISTICAS_JOGADORES;

delete from ESTATISTICAS_JOGO;

delete from COMPRAR;

delete from JOGA_MJ;

delete from MULTIJOGADOR;

delete from NORMAL;

delete from CONVERSAS;

delete from JOGOS;

delete from JOGADORES;

delete from REGIAO;
